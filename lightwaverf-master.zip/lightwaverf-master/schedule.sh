#!/bin/bash
source /home/pi/.profile && /usr/local/bin/lightwaverf schedule true
